/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package and_s_10016_u2_l2_video2_actividad1respuesta_v1;

/**
 *
 * @author Next University
 */
public class AND_S_10016_U2_L2_Video2_Actividad1Respuesta_V1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean a = 7 < 8;
        boolean b=  1 > 2;
        boolean c=  3<=5;
        boolean d=(5<6 && 7<10);
        boolean e=(12>5 || 3<2);
        
        System.out.println(a+"\n"+b+"\n"+""+c+"\n"+d+"\n"+e);
        
    }
    
}
