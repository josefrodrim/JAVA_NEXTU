/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package and_s_10016_u2_l2_video1_actividad2respuesta_v1;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class AND_S_10016_U2_L2_Video1_Actividad2Respuesta_V1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado= new Scanner(System.in);
        
        System.out.println("Ingresa la primera variable");
        int a=teclado.nextInt();
        System.out.println("Ingresa la segunda variable");
        int b=teclado.nextInt();
        
        System.out.println(a+b);
        System.out.println(a-b);
        System.out.println(a*b);
        System.out.println(a/b);
        System.out.println(a%b);
   
                
                
    }
    
}
