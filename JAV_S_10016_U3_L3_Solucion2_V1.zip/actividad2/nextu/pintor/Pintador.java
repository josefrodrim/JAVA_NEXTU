package nextu.pintor;

public class Pintador {

    public void pintar(){
        
    }
}
