package nextu.pintor;

public class Lienzo {
    private String colorDeFondo = "negro";
}
