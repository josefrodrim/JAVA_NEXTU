package nextu.pintor;

public class Brocha extends Pintador {
    public void pintar(){
        System.out.println("Pintando con brocha...");
    }
}
