package nextu.pintor;

public class Tela extends Lienzo {
    private String colorDeFondo = "gris";
}
