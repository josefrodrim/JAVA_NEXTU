package nextu.pintor;

public class Papel extends Lienzo {
    private String colorDeFondo = "blanco";
}
