package nextu.pintor;

public class Pincel extends Pintador {

    public void pintar(){
        System.out.println("Pintando con pincel...");
    }
    
}
